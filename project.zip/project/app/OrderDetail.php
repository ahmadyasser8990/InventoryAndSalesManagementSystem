<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderDetail extends Model
{
    protected $table ='order_details';
    protected $fillable =['order_id', 'product_id','customer_name'
                        ,'customer_phone' ,'sale_price'
                            ,'quantity', 'amount', 'note'];
}
