<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{

    protected $guarded = [];

    protected $casts = [
        'phone' => 'array'
    ];

    protected $appends = ['image_path'];

    public function getNameAttribute($value)
    {
        return ucfirst($value);
    } // end of name to make first letter upper case

    public function getImagePathAttribute()
    {
        return asset('uploads/user_images/' . $this->image);

    }//end of image path attribute
}
