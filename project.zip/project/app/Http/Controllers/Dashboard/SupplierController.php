<?php

namespace App\Http\Controllers\Dashboard;

use App\Supplier;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class SupplierController extends Controller
{

    public function index(Request $request)
    {
        $suppliers = Supplier::when($request->search, function($q) use($request){

            return $q->where('name','like', '%' . $request->search . '%')
            ->orwhere('phone','like', '%' . $request->search . '%')
            ->orwhere('address','like', '%' . $request->search . '%');

        })->latest()->paginate(5);

        return view('dashboard.suppliers.index', compact('suppliers'));
    }

    public function create()
    {
        return view('dashboard.suppliers.create');
    }

    public function store(Request $request)
    {
        $request->validate([

            'name' => 'required',
            'phone' => 'required|array|min:1',
            'phone.0' => 'required',
            'address' => 'required',
        ]);

        $request_data = $request->all();
        $request_data['phone'] = array_filter($request->phone);


        if ($request->image) {



            Image::make($request->image)
                ->resize(300, null, function ($constraint) {
                    $constraint->aspectRatio();
                })
                ->save(public_path('uploads/user_images/' . $request->image->hashName()));

            $request_data['image'] = $request->image->hashName();

        }//end of if

        Supplier::create($request_data);
        session()->flash('success', __('site.added_successfully'));
        return redirect()->route('dashboard.suppliers.index');
    }

    public function edit(Supplier $supplier)
    {
        return view('dashboard.suppliers.edit', compact('supplier'));
    }

    public function update(Request $request, Supplier $supplier)
    {
        $request->validate([

            'name' => 'required',
            'phone' => 'required|array|min:1',
            'phone.0' => 'required',
            'address' => 'required',
        ]);

        $request_data = $request->all();
        $request_data['phone'] = array_filter($request->phone);

        if ($request->image) {

            if ($supplier->image != 'default.png') {

                Storage::disk('public_uploads')->delete('/user_images/' . $supplier->image);

            }//end of inner if


            Image::make($request->image)
                ->resize(300, null, function ($constraint) {
                    $constraint->aspectRatio();
                })
                ->save(public_path('uploads/user_images/' . $request->image->hashName()));

            $request_data['image'] = $request->image->hashName();

        }//end of if

        $supplier->update($request_data);

        session()->flash('success', __('site.updated_successfully'));
        return redirect()->route('dashboard.suppliers.index');

    }

    public function destroy(Supplier $supplier)
    {
        if ($supplier->image != 'default.png') {

            Storage::disk('public_uploads')->delete('/user_images/' . $supplier->image);

        }//end of if

        $supplier->delete();
        session()->flash('success',__('site.deleted_successfully'));
        return redirect()->route('dashboard.suppliers.index');
    }
}
