<?php

namespace App\Http\Controllers\Dashboard;

use App\Order;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use Illuminate\Support\Facades\DB;

class SaleController extends Controller
{

    public function index()
    {

        $products = Product::all();
        $sales = Order::all();
        return view('dashboard.sales.index', compact('sales','products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        return($this->amount_order($request));

        // DB::transaction(function () use($request) {
        //     //ORDER MODEL
        //     $orders = new Order;
        //     $orders->name = $request->customer_name;
        //     $orders->total_price = $request->customer_name;
        //             //ORDER_DETAILS MODEL

        //             //TRANSACTION MODEL
        // });

    }

    private function amount_order($request){



        $amount = 0;

        foreach($request->quantity as $quantity ){

            $amount += $request->sale_price * $quantity;
        }

        return($amount);
        // $orders = new Order;
        // $orders->total_price =
    }

    public function show(Order $order)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        //
    }
}
