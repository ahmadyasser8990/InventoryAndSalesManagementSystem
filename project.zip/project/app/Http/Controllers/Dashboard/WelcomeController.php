<?php

namespace App\Http\Controllers\Dashboard;

use App\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use App\Supplier;
use App\User;


class WelcomeController extends Controller
{


    public function index()
    {

        $users_count = User::whereRoleIs('admin')->count();
        $product_count = Product::count();
        $category_count = Category::count();
        $supplier_count = Supplier::count();

        return view('dashboard.welcome', compact('users_count','supplier_count', 'product_count', 'category_count'));

    }//end of index
}//end of class
