$(document).ready(function() {

    //ع شان نظيف صف جديد بفاتورة البيع
    $('.add_more').on('click', function() {

        var product = $('.product_id').html();
        var numberofrow = ($('.addMoreProduct tr').length - 0) + 1;
        var tr = `<tr><td class="no">  ${numberofrow}  </td>
        <td>
            <select name="product_id[]" class="form-control product_id">

                ${product}

            </select>
        </td>
        <td><input type="text" class="form-control input-sm name " name="name[]"  placeholder="اسم القطعة" disabled></td>
        <td><input type="number" class="form-control input-sm quantity" name="quantity[]"  min="1" value="1" placeholder="الكمية"></td>
        <td><input type="number" class="form-control input-sm sale_price" name="sale_price[]" placeholder="سعر البيع"></td>
        <td> <p> <b><span class="amount" name="amount[]">0</span> ريال </b> </p></td>
        <td><a class="btn btn-sm btn-danger"><i class="icon-remove_circle"></i></a></td>`

        $('.addMoreProduct').append(tr);
        // calculate_total();
    });

    //لحذف اي صف داخل فاتورة البيع
    $('.addMoreProduct').delegate('.delete', 'click', function() {

        $(this).parent().parent().remove();

        calculate_total();
    });




    //تختار القطعه ويجيب لك بيناتها
    $('.addMoreProduct').delegate('.product_id', 'change', function() {
        var tr = $(this).parent().parent();
        var name = tr.find('.product_id option:selected').attr('data-name');
        tr.find('.name').val(name);
    });


    //بعد اضافة السعر يتغير الاجمالي
    $('body').on('change', '.sale_price', function(e) {

        e.preventDefault();
        var tr = $(this).parent().parent();
        var sale_price = tr.find('.sale_price').val();

        var qty = tr.find('.quantity').val();

        var amount = parseFloat(qty) * parseFloat(sale_price);

        if (!isNaN(amount)) {
            tr.find('.amount').html($.number(amount, 2));
        } else {
            tr.find('.amount').html(0);
        }

        calculate_total();

    });


    //بعد اضافة الكمية يتغير الاجمالي
    $('body').on('change', '.quantity', function(e) {

        e.preventDefault();
        var tr = $(this).parent().parent();
        var sale_price = tr.find('.sale_price').val();

        var qty = tr.find('.quantity').val();

        var amount = parseFloat(qty) * parseFloat(sale_price);


        if (!isNaN(amount)) {
            tr.find('.amount').html($.number(amount, 2));
        } else {
            tr.find('.amount').html(0);
        }

        calculate_total();
    });

});


function calculate_total() {

    var total_price = 0;
    // (each) -> مهمتها تعدي على كل صف موجود عندي بالجدول
    $('.addMoreProduct .amount').each(function(index) {



        total_price += parseFloat($(this).html().replace(/,/g, ''));

    })

    $('.total_price').html($.number(total_price, 2));


    if (total_price > 0) {

        $('#add-order-form-btn').removeClass('disabled');

    } else {

        $('#add-order-form-btn').addClass('disabled');

    }

}