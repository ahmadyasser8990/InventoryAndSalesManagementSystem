$(document).ready(function() {



    //for showing orders in reports/ sales
    $('.order-products').on('click', function(e) {



        e.preventDefault();

        $('#loading').css('display', 'flex');

        var url = $(this).data('url');
        var method = $(this).data('method');

        $.ajax({

            url: url,
            method: method,

            success: function(data) {

                $('#loading').css('display', 'none');

                $('#order-product-list').empty();
                $('#order-product-list').append(data);

            }
        })

    }); // end of showing of sales.

    //for showing orders in reports/ purchases
    $('.purchases-products').on('click', function(e) {



        e.preventDefault();

        $('#loading').css('display', 'flex');

        var url = $(this).data('url');
        var method = $(this).data('method');

        $.ajax({

            url: url,
            method: method,

            success: function(data) {

                $('#loading').css('display', 'none');

                $('#purchases-product-list').empty();
                $('#purchases-product-list').append(data);

            }
        })

    }); // end of showing purchases.

    // //print report
    // $(document).on('click', '.print-btn', function() {

    //     $('#print-area').printThis();
    // }); // end of click function

    //print sale invoice
    $(document).on('click', '.print-sale-btn', function() {

        $('#invoice-area').printThis();
    }); // end of click function

}); // end of redy function