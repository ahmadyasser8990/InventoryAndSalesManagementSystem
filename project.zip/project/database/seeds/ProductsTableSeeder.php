<?php

use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $name = ['الخواتم', 'الساعات', 'اطقم', 'اساور', 'حلقان','سلسل'];

        foreach($name as $name){

            \App\Product::create([
                'category_id' => 1,
                'code' => '1205',
                'name' => $name,
                'description' => 'My name is ahmed yaser',
                'purchase_price' => 1400,
                'stock' => 100,
            ]);
        }


    }
}
