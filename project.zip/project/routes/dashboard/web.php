<?php

use Illuminate\Support\Facades\Route;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

Route::group(['prefix' => LaravelLocalization::setLocale(),
    'middleware'=>['localeSessionRedirect', 'localizationRedirect','localeViewPath']
],
function() {


    Route::prefix('dashboard')->name('dashboard.')->middleware(['auth'])->group(function(){


        // الداش بورد
        Route::get('/', 'WelcomeController@index')->name('welcome');


        //المشرفين
        Route::resource('users', 'UserController')->except(['show']);

        //المنتجات
        Route::resource('products', 'ProductController')->except(['show']);

        //الاقسام
        Route::resource('categories', 'CategoryController')->except(['show']);

        //الموردين
        Route::resource('suppliers', 'SupplierController')->except(['show']);

        //المبيعات
        Route::resource('sales', 'SaleController')->except(['show']);




            // فاتورة شراء
            Route::get('/purchases', function(){

                return view('dashboard.purchases.index');
            });

            // فاتورة شراء
            Route::get('/purchases/invoice', function(){

                return view('dashboard.purchases.invoice');
            });

            // // فاتورة بيع
            // Route::get('/sales', function(){

            //     return view('dashboard.sales.index');
            // });

            //فاتورة بيع
            Route::get('/sales/invoice', function(){

                return view('dashboard.sales.invoice');
            });

            // مرتجع مبيعات
            Route::get('/return_sale', function(){

                return view('dashboard.sales.return_sale');
            });

            // مرتجع مشتريات
            Route::get('/return_purchase', function(){

                return view('dashboard.purchases.return_purchase');
            });

            // //  المشرفين
            // Route::get('/users', function(){

            //     return view('dashboard.users.index');
            // });

            // //  اظافة المشرفين
            // Route::get('/users/create', function(){

            //     return view('dashboard.users.create');
            // });

            // //  المخزون
            // Route::get('/products', function(){

            //     return view('dashboard.products.index');
            // });

            // //  اظافة المخزون
            // Route::get('/products/create', function(){

            //     return view('dashboard.products.create');
            // });

            // //  الموردين
            // Route::get('/suppliers', function(){

            //     return view('dashboard.suppliers.index');
            // });

            // //   الموردين اظافة
            // Route::get('/suppliers/create', function(){

            //     return view('dashboard.suppliers.create');
            // });


            //   تقارير
            Route::get('/reports', function(){

                return view('dashboard.reports.index');
            });

            //     تقارير المشتريات
            Route::get('/reports/purchases', function(){

                return view('dashboard.reports.purchases.purchases');
            });

            //    عرض  فاتورة المشتريات
            Route::get('/reports/purchases/show', function(){

                return view('dashboard.reports.purchases._products');
            });

            //    عرض  فاتورة المشتريات
            Route::get('/reports/purchases/invoice', function(){

                return view('dashboard.reports.purchases.invoice');
            });

            //     تقارير المبيعات
            Route::get('/reports/sales', function(){

                return view('dashboard.reports.sales.sales');
            });

            //    عرض  فاتورة المبيعات
            Route::get('/reports/sales/show', function(){

                return view('dashboard.reports.sales._products');
            });
            //    عرض  فاتورة المبيعات
            Route::get('/reports/sales/invoice', function(){

                return view('dashboard.reports.sales.invoice');
            });




        });
});
