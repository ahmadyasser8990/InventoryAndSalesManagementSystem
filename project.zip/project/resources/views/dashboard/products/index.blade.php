@extends('layouts.dashboard.app')

@section('content')


    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item active">Store</li>
        </ol>
    </div>
    <!-- Page header end -->

    {{-- category --}}

    <!-- Content wrapper start -->
    <div class="content-wrapper" style=" min-height: calc(50vh - 150px); background: #c2c5d5;">

        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="card-header">

                        <div class="card-title">Category</div>

                        <div class="mb-2"></div>

                        <div class="row">

                            <div class="col-md-2">

                                <p> All Categories</p>

                            </div>

                            <div class="col-md-4">

                                <button type="button" data-toggle="modal" data-target="#newCategory" class="btn btn-primary"><i class="icon-circle-with-plus"></i> Create New Category</button>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row gutters">

            @if ($categories->count()>0)
            @foreach ($categories as $category)
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                <div class="card lobipanel-sortable">

                    <div class="card-header">
                        <div class="card-title">{{$category->name}}</div>
                    </div>

                    <div class="card-body ">
                        <a href="{{route('dashboard.categories.index', ['category_id' =>$category->id])}}" class="btn btn-info btn-sm"> All items that realted to this category</a>
                        <small>({{$category->products->count()}}) </small>
                    </div>
                    <div class="card-footer text-right">

                        @if (auth()->user()->hasPermission('update_categories'))

                            <a href="{{route('dashboard.categories.edit', $category->id)}}"  class="btn btn-success "><i class="icon-edit"></i></a>

                        @else
                            <a href="#" class="btn btn-success disabled"><i class="icon-edit"></i></a>

                        @endif

                        @if (auth()->user()->hasPermission('delete_categories'))

                            <form action="{{route('dashboard.categories.destroy', $category->id)}}" method="POST" style="display: inline-block">

                                {{ csrf_field() }}
                                {{ method_field('delete') }}

                                <button type="submit" name="edit" class="btn delete  btn-danger" ><i class="icon-delete"></i></button>

                            </form>

                        @else

                            <button type="submit" name="edit" class="btn btn-danger disabled" ><i class="icon-delete"></i></button>

                        @endif
                    </div>

                </div>
            </div>

            @endforeach

            @else

                <h2 class="text-left">No Data Found</h2>

            @endif

        </div>

    <!-- Content wrapper start -->
    <div class="content-wrapper">

        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">

                    <div class="card-header">

                        <div class="card-title">Store</div>

                        <div class="mb-2"></div>

                        <div class="row gutters justify-content-end">

                            <div class="col-md-2">

                                <h5>All Items  : <span class="total-price">{{$products->count()}}</span></h5>
                            </div>

                            <div class="col-md-2">

                                <h5>Total Purchase  : <span class="total-price">0</span></h5>

                            </div>



                        </div>

                        <form action="{{route('dashboard.products.index')}}" method="get">

                            <div class="row">

                                <div class="col-md-4" style="margin-bottom: 10px">
                                    <input type="text" name="search" class="form-control" placeholder="Search" value="{{ request()->search}}">
                                </div>

                                <div class="col-md-4">

                                    <select name="category_id" class="form-control">
                                        <option value="">All Categories</option>
                                        @foreach ($categories as $category )
                                            <option value="{{$category->id}}" {{ request()->category_id == $category->id ? 'selected' : '' }}>{{$category->name}}</option>
                                        @endforeach
                                    </select>

                                </div>

                                <div class="col-md-4">

                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>

                                    <a href="{{route('dashboard.products.create')}}" class="btn btn-info"><i class="icon-circle-with-plus"></i> Create New Item</a>

                                    <a href="{{route('dashboard.products.index')}}" class="btn btn-primary"><i class=""></i> All Items</a>

                                </div>

                            </div>

                        </form>  {{--end of form --}}

                    </div>

                    <div class="card-body p-0">
                        @if ($products->count()>0)
                            <div class="table-responsive">
                                <table class="table projects-table">
                                    <thead>
                                        <tr>
                                            <th>Image</th>
                                            <th>Item Code</th>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Category</th>
                                            <th>Quantity</th>
                                            <th>Purchase Price</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($products as $index=>$product )

                                            <tr>
                                                <td>
                                                    <div class="text-avatar-group">
                                                        <img class="text-avatar  xl" style="background-color:transparent; width:auto;" src="{{$product->image_path}}" class="avatar" alt="Wafi Admin">
                                                    </div>
                                                </td>
                                                <td><span style="color: black;">BR00 </span>{{$product->code}}</td>
                                                <td>
                                                    <div class="project-details">
                                                        <div class="project-info">
                                                            <p>{{$product->name}} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="project-details">
                                                        <div class="project-info">
                                                            <p>{!! $product->description !!} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="project-details">
                                                        <div class="project-info">
                                                            <p>{{$product->category->name}} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="text-avatar-group">
                                                        <div class="project-info">
                                                            @if ($product->stock <= 5 )

                                                                <span class="badge badge-danger"> الكمية قليلة - ( {{$product->stock}} )</span>

                                                            @else

                                                                <span class="badge badge-success">  {{$product->stock}}</span>

                                                            @endif
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="text-avatar-group">
                                                        <div class="project-info">
                                                            <p>{{number_format($product->purchase_price,2)}} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>

                                                    @if (auth()->user()->hasPermission('delete_products'))

                                                        <form action="{{route('dashboard.products.destroy', $product->id)}}" method="POST" style="display: inline-block">

                                                            {{ csrf_field() }}
                                                            {{ method_field('delete') }}

                                                            <button type="submit" name="remove" class="btn delete btn-danger"><i class="icon-remove_circle"></i></button>

                                                        </form>
                                                    @else

                                                        <button type="submit" name="remove" class="btn  btn-danger disabled"><i class="icon-remove_circle"></i></button>

                                                    @endif

                                                    @if (auth()->user()->hasPermission('update_products'))

                                                        <a href="{{route('dashboard.products.edit', $product->id)}}"  class="btn btn-success "><i class="icon-edit"></i></a>
                                                    @else

                                                        <a href="#"  class="btn btn-success disabled"><i class="icon-edit"></i></a>

                                                    @endif
                                                </td>
                                            </tr>

                                        @endforeach

                                    </tbody>
                                </table>
                            </div>
                            {{ $products->appends(request()->query())->links() }}

                        @else

                            <h2>@lang('site.no_data_found')</h2>

                        @endif
                    </div>
                </div>
            </div>
        </div>

    </div>


    <!-- Modal New Category -->
    <div class="modal fade" id="newCategory" tabindex="-1" role="dialog" aria-labelledby="newCategoryLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                @include('partials._errors')

                <form action="{{route('dashboard.categories.store')}}" method="POST">

                    {{ csrf_field() }}
                    {{ method_field('post')}}

                    <div class="modal-header">
                        <h5 class="modal-title" id="newCategoryLabel">@lang('site.new_category')</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">


                        <div class="form-group">
                            <label>@lang('site.name')</label>
                            <input type="text" class="form-control" name="name" value="{{ old('name') }}" placeholder="ادخل اسم القسم" required>
                        </div>

                    </div>

                    <div class="modal-footer custom">

                        <div class="right-side">
                            <button type="submit" class="btn btn-link success">@lang('site.create')</button>
                        </div>

                        <div class="divider"></div>

                        <div class="left-side">
                            <button type="button" class="btn btn-link danger" data-dismiss="modal">@lang('site.close')</button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>



@endsection
