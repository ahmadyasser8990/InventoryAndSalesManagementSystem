@extends('layouts.dashboard.app')


@section('content')

    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{route('dashboard.products.index')}}">Store</a></li>
            <li class="breadcrumb-item active">Create</li>
        </ol>
    </div>
    <!-- Page header end -->

<!-- Content wrapper start -->
<div class="content-wrapper">
    <!-- Row start -->
    <div class="row gutters">

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

            <div class="card h-100">

                <div class="card-header">
                    <div class="card-title">Create Item</div>
                </div>

                <div class="card-body">

                    @include('partials._errors')

                    <form action="{{route('dashboard.products.store')}}" method="POST" enctype="multipart/form-data">

                        {{ csrf_field() }}
                        {{ method_field('post')}}

                        <div class="row gutters">

                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">

                                <div class="form-group">

                                    <label>Category</label>

                                    <select name="category_id" class="form-control">

                                        <option value="">All Category</option>

                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                                        @endforeach

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label >Item Code</label>
                                    <input type="text" class="form-control" name="code" value="{{old('code')}}" placeholder="ادخل رقم الصنف الجديد" >
                                </div>
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="name" value="{{old('name')}}" placeholder="ادخل اسم الصنف" >
                                </div>
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea name="description" class="form-control ckeditor">{{ old('description') }}</textarea>
                                </div>
                            </div>

                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">

                                <div class="form-group">
                                    <label >Stock</label>
                                    <input type="number" class="form-control" name="stock" value="{{old('stock')}}" placeholder="ادخل الكمية / الوزن" >
                                </div>

                                <div class="form-group">
                                    <label>Purchase Price</label>
                                    <input type="number" class="form-control" name="purchase_price" step="0.01" placeholder="ادخل سعر الشراء" >
                                </div>

                                <div class="form-group">

                                    <label>Image</label>
                                    <input type="file" name="image" class="form-control image">

                                </div>
                                <div class="form-group">

                                    <img src="{{asset('uploads/product_images/default.png')}}" style="width: 100px;" class=" image-preview" >

                                </div>

                            </div>

                        </div>
                            <!-- Row start -->
                        <div class="row gutters">

                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="">

                                    <a href="{{route('dashboard.products.index')}}"  class="btn btn-dark">Cancel</a>

                                    <button type="submit" class="btn btn-success">Create</button>
                                </div>
                            </div>


                        </div>
                        <!-- Row end -->

                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- Row end -->

</div>




@endsection
