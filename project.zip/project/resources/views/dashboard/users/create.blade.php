@extends('layouts.dashboard.app')


@section('content')

    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{route('dashboard.users.index')}}">Users</a></li>
            <li class="breadcrumb-item active">Create</li>
        </ol>
    </div>
    <!-- Page header end -->

    <!-- Content wrapper start -->
    <div class="content-wrapper">
        <!-- Row start -->
        <div class="row gutters">

            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                <div class="card h-100">

                    <div class="card-header">
                        <div class="card-title">Create User</div>
                    </div>

                    <div class="card-body">

                        @include('partials._errors')

                        <form action="{{route('dashboard.users.store')}}" method="POST" enctype="multipart/form-data">

                            {{ csrf_field() }}
                            {{ method_field('post')}}

                            <div class="row gutters">

                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="form-group">
                                        <label>First Name</label>
                                        <input type="text" class="form-control" name="first_name" value="{{ old('first_name') }}" placeholder="First Name">
                                    </div>
                                    <div class="form-group">
                                        <label>Last Name</label>
                                        <input type="text" class="form-control" name="last_name" value="{{ old('last_name') }}" placeholder="Last Name">
                                    </div>

                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="number" class="form-control" name="phone_no" value="{{ old('phone_no') }}" placeholder="Phone">
                                    </div>

                                </div>

                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">

                                    <div class="form-group">
                                        <label>Email Address</label>
                                        <input type="email" class="form-control" name="email" value="{{ old('email') }}" placeholder="Email Address ">
                                    </div>

                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" class="form-control" name="password" placeholder=" Password">
                                    </div>

                                    <div class="form-group">
                                        <label>Password Confirmation</label>
                                        <input type="password" class="form-control" name="password_confirmation" placeholder=" Confirm Password ">
                                    </div>



                                </div>

                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">


                                    <div class="form-group">

                                        <label>Image</label>
                                        <input type="file" name="image" class="form-control image">

                                    </div>

                                    <div class="form-group">

                                        <img src="{{asset('uploads/user_images/default.png')}}" style="width: 100px;" class="img-thumbnail image-preview" alt="">

                                    </div>

                                </div>

                            </div>
                                <!-- Row start -->
                            <div class="row gutters">

                                @php
                                    $models = ['users','sales', 'purchases', 'reports','products','categories','suppliers'];

                                    $maps = ['create','read','update', 'delete'];
                                @endphp

                                {{-- صلاحيات الفواتير --}}

                                @foreach ($models as $index=>$model )

                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                        <div class="card bg-primary ">

                                            <div class="card-header">

                                                {{-- <div class="card-title" style="color:white; ">@lang('site.permissions_'. $model)</div> --}}
                                                <div class="card-title" style="color:white; ">Permissioins {{$model}}</div>

                                            </div>

                                            <div class="card-body">

                                                @foreach ($maps as $map)


                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input" id="{{$map . '_' .$model}}" name="permissions[]" value="{{$map . '_' .$model}}">
                                                    <label class="custom-control-label" style="color:white; " for="{{$map . '_' .$model}}"> {{$map}}</label>
                                                </div>

                                                <div class="mb-2"></div>

                                                @endforeach

                                            </div>
                                        </div>
                                    </div>

                                @endforeach

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="form-group">

                                        <a href="{{route('dashboard.users.index')}}"  class="btn btn-dark">Cancel</a>

                                        <button type="submit" class="btn btn-success">Create</button>
                                    </div>
                                </div>


                            </div>
                            <!-- Row end -->

                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->

    </div>




@endsection
