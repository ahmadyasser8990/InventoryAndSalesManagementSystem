@extends('layouts.dashboard.app')


@section('content')

    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{route('dashboard.suppliers.index')}}">Supplier</a></li>
            <li class="breadcrumb-item active">Create</li>
        </ol>
    </div>
    <!-- Page header end -->

<!-- Content wrapper start -->
<div class="content-wrapper">
    <!-- Row start -->
    <div class="row gutters">

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

            <div class="card h-100">

                <div class="card-header">
                    <div class="card-title">Create Supplier</div>
                </div>

                <div class="card-body">

                    @include('partials._errors')

                    <form action="{{route('dashboard.suppliers.store')}}" method="POST" enctype="multipart/form-data">

                        {{ csrf_field() }}
                        {{ method_field('post')}}

                        <div class="row gutters">

                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" name="name" class="form-control" value="{{ old('name')}}">
                                </div>
                                @for ($i = 0; $i < 2; $i++)

                                    <div class="form-group">
                                        <label for="">Phone</label>
                                        <input type="text" name="phone[]" class="form-control">
                                    </div>

                                @endfor

                            </div>

                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">

                                <div class="form-group">
                                    <label for="">Address</label>
                                    <textarea name="address" class="form-control">{{old('address')}}</textarea>
                                </div>

                                <div class="form-group">

                                    <label>Image</label>
                                    <input type="file" name="image" class="form-control image">

                                </div>
                                <div class="form-group">

                                    <img src="{{asset('uploads/user_images/default.png')}}" style="width: 100px;" class="img-thumbnail image-preview" alt="">

                                </div>

                            </div>

                        </div>
                            <!-- Row start -->
                        <div class="row gutters">

                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="">

                                    <a href="{{route('dashboard.suppliers.index')}}"  class="btn btn-dark">Cancel</a>

                                    <button type="submit" class="btn btn-success">Create</button>

                                </div>
                            </div>


                        </div>
                        <!-- Row end -->

                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- Row end -->

</div>




@endsection
