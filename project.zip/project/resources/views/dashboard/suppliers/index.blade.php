@extends('layouts.dashboard.app')

@section('content')


    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="{{route('dashboard.suppliers.index')}}">Supplier</a></li>
        </ol>
    </div>
    <!-- Page header end -->


    <!-- Content wrapper start -->
    <div class="content-wrapper">

        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">

                    <div class="card-header">

                        <div class="card-title" style="margin-bottom: 15px">
                            Suppliers
                            <small>({{$suppliers->total()}})</small>
                        </div>

                        <form action="{{route('dashboard.suppliers.index')}}" method="get">

                            <div class="row">

                                <div class="col-md-4" style="margin-bottom: 10px">
                                    <input type="text" name="search" class="form-control" placeholder="Search" value="{{ request()->search}}">
                                </div>

                                <div class="col-md-4">

                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>

                                    @if (auth()->user()->hasPermission('create_suppliers'))

                                        <a href="{{route('dashboard.suppliers.create')}}" class="btn btn-primary"><i class="icon-circle-with-plus"></i> Create</a>

                                    @else

                                        <a href="#" class="btn btn-primary disabled"><i class="icon-circle-with-plus"></i> Create</a>

                                    @endif

                                </div>

                            </div>

                        </form>  {{--end of form --}}


                        <div class="row gutters justify-content-end">

                            <div class="col-md-2">
                            </div>

                        </div>

                    </div>

                    <div class="card-body p-0">

                        @if ($suppliers->count()>0)

                            <div class="table-responsive">
                                <table class="table projects-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Phone</th>
                                            <th>Address</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($suppliers as $index=>$supplier )

                                            <tr>
                                                <td> {{$index + 1 }}</td>
                                                <td>
                                                    <div class="project-details">
                                                        <img src="{{$supplier->image_path}}" class="avatar">
                                                        <div class="project-info">
                                                            <p>{{$supplier->name}}</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="project-details">
                                                        <div class="project-info">
                                                            <p>{{ is_array($supplier->phone) ? implode($supplier->phone, ' - ') : $supplier->phone}}</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="project-details">
                                                        <div class="project-info">
                                                            <p>{{$supplier->address}}</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    @if (auth()->user()->hasPermission('update_suppliers'))

                                                        <a href="{{route('dashboard.suppliers.edit', $supplier->id)}}" class="btn btn-success"><i class="icon-edit"></i></a>

                                                    @else

                                                    <a href="#" class="btn btn-success disabled"><i class="icon-edit"></i></a>

                                                    @endif

                                                    @if (auth()->user()->hasPermission('delete_suppliers'))

                                                        <form action="{{route('dashboard.suppliers.destroy', $supplier->id)}}" method="POST" style="display: inline-block">

                                                            {{ csrf_field() }}
                                                            {{ method_field('delete') }}

                                                            <button type="submit" name="edit" class="btn delete btn-danger" ><i class="icon-remove_circle"></i></button>

                                                        </form>

                                                    @else

                                                        <button type="submit" name="edit" class="btn btn-danger disabled" ><i class="icon-remove_circle"></i></button>

                                                    @endif
                                                </td>
                                            </tr>

                                        @endforeach

                                    </tbody>
                                </table>
                            </div>

                        {{ $suppliers->appends(request()->query())->links() }}

                        @else

                            <h2>No Data Found</h2>

                        @endif
                    </div>
                </div>
            </div>
        </div>

    </div>




@endsection
