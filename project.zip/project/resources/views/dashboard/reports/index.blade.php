@extends('layouts.dashboard.app')


@section('content')

    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="{{asset('dashboard/reports')}}">Reports</a></li>
        </ol>
    </div>
    <!-- Page header end -->


        <!-- Content wrapper start -->
        <div class="content-wrapper">

            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                    <div class="card lobipanel-sortable">

                        <div class="card-header">
                            <div class="card-title"><a href="{{asset('dashboard/reports/purchases')}}">Purchases</a></div>
                        </div>
                        <div class="card-body"> </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                    <div class="card lobipanel-sortable">
                        <div class="card-header">
                            <div class="card-title"><a href="{{asset('dashboard/reports/sales')}}">Sales</a></div>
                        </div>
                        <div class="card-body"> </div>
                    </div>
                </div>
            </div>
            <!-- Row end -->

        </div>
        <!-- Content wrapper end -->





@endsection
