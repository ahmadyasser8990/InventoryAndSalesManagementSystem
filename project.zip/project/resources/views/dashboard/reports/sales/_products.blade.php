<div>
    <table class="table table-hover table-bordered">

        <thead>
        <tr>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Price</th>
        </tr>
        </thead>

        <tbody>
        @for ($i=0; $i<3 ; $i++)
            <tr>
                <td>احمد ياسر</td>
                <td>15000</td>
                <td>{{ number_format(1065, 2) }}</td>
            </tr>
        @endfor
        </tbody>
    </table>
    <h3>Total Payment <span>{{ number_format(164000, 2) }}</span></h3>

</div>
<form action="{{asset('dashboard/reports/sales/invoice')}}" method="get">
    <button class="btn btn-block btn-primary"><i class=""></i>Show Invoice</button>
</form>
