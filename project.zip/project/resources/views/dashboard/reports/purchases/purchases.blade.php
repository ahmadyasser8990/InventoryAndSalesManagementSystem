@extends('layouts.dashboard.app')


@section('content')

    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{asset('dashboard/reports')}}">Reports</a></li>
            <li class="breadcrumb-item active"><a href="{{asset('dashboard/reports/purchases')}}">Purchases</a></li>
        </ol>
    </div>
    <!-- Page header end -->



     <!-- Content wrapper start -->
     <div class="content-wrapper">
        <div class="row">

            <div class="col-md-8">

                <!-- Row start -->
                <div class="row gutters">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">

                            <div class="card-header">

                                <div class="card-title">Purchases</div>

                                <div class="mb-2"></div>

                                <div class="row gutters justify-content-end">

                                    <div class="col-md-3">

                                        <h5>Totally Purchases   : <span class="total-price">0</span></h5>

                                    </div>

                                </div>

                                <form action="#" method="get">

                                    <div class="row">

                                        <div class="col-md-4">
                                            <input type="text" name="search" class="form-control" placeholder="@lang('site.search')" value="{{ request()->search}}">
                                        </div>

                                        <div class="col-md-4">

                                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>

                                        </div>

                                    </div>

                                </form>  {{--end of form --}}

                            </div>

                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table projects-table">
                                        <thead>
                                            <tr>
                                                <th>Supplier Name</th>
                                                <th>Price</th>
                                                <th>Created At</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @for ($i=0; $i<3 ; $i++)


                                            <tr>
                                                <td> ناصر محمد </td>
                                                <td>{{ number_format(1500, 2) }}</td>
                                                <td> 12/5/2021 </td>

                                                <td>
                                                    <button class="btn btn-primary btn-sm purchases-products"
                                                                data-url="{{ asset('dashboard/reports/purchases/show') }}"
                                                                data-method="get">

                                                            <i class="fa fa-list"></i>

                                                            Show

                                                    </button>

                                                    <a href="#" disabled class="btn btn-warning btn-sm"><i class="fa fa-edit"></i> Edit</a>

                                                    <form action="#" method="post" style="display: inline-block;">
                                                        {{ csrf_field() }}
                                                        {{ method_field('delete') }}
                                                        <button type="submit" class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i> Delete</button>
                                                    </form>

                                                </td>
                                            </tr>

                                            @endfor

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-4">

                <div class="box box-primary">

                    <div class="box-header">
                        <h3 class="box-title" style="margin-bottom: 10px">Show Invoice Here</h3>
                    </div><!-- end of box header -->

                    <div class="box-body">

                        <div style="display: none; flex-direction: column; align-items: center;" id="loading">
                            <div class="loader"></div>
                            <p style="margin-top: 10px">Loading</p>
                        </div>

                        <div id="purchases-product-list">

                        </div><!-- end of order product list -->

                    </div><!-- end of box body -->

                </div><!-- end of box -->

            </div><!-- end of col -->

        </div>

    </div>

@endsection
