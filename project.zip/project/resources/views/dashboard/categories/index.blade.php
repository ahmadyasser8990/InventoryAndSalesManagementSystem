@extends('layouts.dashboard.app')

@section('content')


    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{route('dashboard.products.index')}}">@lang('site.products')</a></li>
            <li class="breadcrumb-item active">@lang('site.edit_category')</li>
        </ol>
    </div>
    <!-- Page header end -->

    <!-- Content wrapper start -->
    <div class="content-wrapper">

        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">

                    <div class="card-header">

                        <div class="card-title">@lang('site.store')</div>

                        <div class="mb-2"></div>

                        <div class="row gutters justify-content-end">

                            <div class="col-md-2">

                                <h5>عدد القطع  : <span class="total-price">{{$products->count()}}</span></h5>
                            </div>

                            <div class="col-md-2">

                                <h5>اجمالي الشراء  : <span class="total-price">0</span></h5>

                            </div>



                        </div>

                        <form action="#" method="get">

                            <div class="row">

                                <div class="col-md-4" style="margin-bottom: 10px">
                                    <input type="text" name="search" class="form-control" placeholder="@lang('site.search')" value="{{ request()->search}}">
                                </div>

                                <div class="col-md-4">

                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> @lang('site.search')</button>

                                    <a href="{{route('dashboard.products.create')}}" class="btn btn-primary"><i class="icon-circle-with-plus"></i> @lang('site.add')</a>

                                </div>

                            </div>



                        </form>  {{--end of form --}}

                    </div>

                    <div class="card-body p-0">
                        @if ($products->count()>0)
                            <div class="table-responsive">
                                <table class="table projects-table">
                                    <thead>
                                        <tr>
                                            <th>@lang('site.image')</th>
                                            <th>@lang('site.code')</th>
                                            <th>@lang('site.name')</th>
                                            <th>@lang('site.description')</th>
                                            <th>@lang('site.category')</th>
                                            <th>@lang('site.quantity')</th>
                                            <th>@lang('site.purchase_price')</th>
                                            <th>@lang('site.action')</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($products as $index=>$product )

                                            <tr>
                                                <td>
                                                    <div class="text-avatar-group">
                                                        <img class="text-avatar  xl" style="background-color:transparent; width:auto;" src="{{$product->image_path}}" class="avatar" alt="Wafi Admin">
                                                    </div>
                                                </td>
                                                <td>{{$product->code}}</td>
                                                <td>
                                                    <div class="project-details">
                                                        <div class="project-info">
                                                            <p>{{$product->name}} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="project-details">
                                                        <div class="project-info">
                                                            <p>{!! $product->description !!} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="project-details">
                                                        <div class="project-info">
                                                            <p>{{$product->category->name}} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="text-avatar-group">
                                                        <div class="project-info">
                                                            <p>{{$product->stock}} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="text-avatar-group">
                                                        <div class="project-info">
                                                            <p>{{$product->purchase_price}} </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>

                                                    @if (auth()->user()->hasPermission('delete_products'))

                                                        <form action="{{route('dashboard.products.destroy', $product->id)}}" method="POST" style="display: inline-block">

                                                            {{ csrf_field() }}
                                                            {{ method_field('delete') }}

                                                            <button type="submit" name="remove" class="btn  btn-danger"><i class="icon-remove_circle"></i></button>

                                                        </form>
                                                    @else

                                                        <button type="submit" name="remove" class="btn  btn-danger disabled"><i class="icon-remove_circle"></i></button>

                                                    @endif

                                                    @if (auth()->user()->hasPermission('update_products'))

                                                        <a href="{{route('dashboard.products.edit', $product->id)}}"  class="btn btn-success "><i class="icon-edit"></i></a>
                                                    @else

                                                        <a href="#"  class="btn btn-success disabled"><i class="icon-edit"></i></a>

                                                    @endif
                                                </td>
                                            </tr>

                                        @endforeach

                                    </tbody>
                                </table>
                            </div>
                        @else

                            <h2>@lang('site.no_data_found')</h2>

                        @endif
                    </div>
                </div>
            </div>
        </div>

    </div>


    <!-- Modal New Category -->
    <div class="modal fade" id="newCategory" tabindex="-1" role="dialog" aria-labelledby="newCategoryLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                @include('partials._errors')

                <form action="{{route('dashboard.categories.store')}}" method="POST">

                    {{ csrf_field() }}
                    {{ method_field('post')}}

                    <div class="modal-header">
                        <h5 class="modal-title" id="newCategoryLabel">@lang('site.new_category')</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">


                        <div class="form-group">
                            <label>@lang('site.name')</label>
                            <input type="text" class="form-control" name="name" value="{{ old('name') }}" placeholder="ادخل اسم القسم" required>
                        </div>

                    </div>

                    <div class="modal-footer custom">

                        <div class="right-side">
                            <button type="submit" class="btn btn-link success">@lang('site.create')</button>
                        </div>

                        <div class="divider"></div>

                        <div class="left-side">
                            <button type="button" class="btn btn-link danger" data-dismiss="modal">@lang('site.close')</button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>



@endsection
