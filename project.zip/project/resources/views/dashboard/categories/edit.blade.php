@extends('layouts.dashboard.app')


@section('content')

    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{route('dashboard.products.index')}}">@lang('site.products')</a></li>
            <li class="breadcrumb-item active">@lang('site.edit_category')</li>
        </ol>
    </div>
    <!-- Page header end -->

    <!-- Content wrapper start -->
    <div class="content-wrapper">
        <!-- Row start -->
        <div class="row gutters">

            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                <div class="card h-100">

                    <div class="card-header">
                        <div class="card-title">@lang('site.edit_category')</div>
                    </div>

                    <div class="card-body">

                        @include('partials._errors')

                        <form action="{{route('dashboard.categories.update', $category->id )}}" method="POST" >

                            {{ csrf_field() }}
                            {{ method_field('put')}}

                            <div class="row gutters">

                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="form-group">
                                        <label>@lang('site.name')</label>
                                        <input type="text" class="form-control" name="name" value="{{ $category->name }}" placeholder="ادخل اسم القسم">
                                    </div>

                                </div>


                            </div>
                                <!-- Row start -->
                            <div class="row gutters">

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="form-group">

                                        {{-- <a href="{{route('dashboard.users.index')}}"  class="btn btn-dark">Cancel</a> --}}

                                        <button type="submit" class="btn btn-success">@lang('site.create')</button>
                                    </div>
                                </div>


                            </div>
                            <!-- Row end -->

                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->

    </div>




@endsection
