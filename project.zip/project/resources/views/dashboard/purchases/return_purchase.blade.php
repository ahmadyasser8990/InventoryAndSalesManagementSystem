@extends('layouts.dashboard.app')


@section('content')

        <!-- Page header start -->
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="{{asset('dashboard/return_purchase')}}">@lang('site.purchase_return_back')</a></li>
            </ol>
        </div>
        <!-- Page header end -->


        <!-- Content wrapper start -->
        <div class="content-wrapper">

            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                    <div class="accordion toggle-icons lg" id="toggleIcons">
                        <div class="accordion-container">
                            <div class="accordion-header" id="purchase_bill">
                                <a  href="" class="" data-toggle="collapse" data-target="#toggleIconsCollapseOne" aria-expanded="true" aria-controls="toggleIconsCollapseOne">
                                    @lang('site.purchase_return_back')
                                </a>
                            </div>
                            <div id="toggleIconsCollapseOne" class="collapse show" aria-labelledby="purchase_bill" data-parent="#toggleIcons">
                                <div class="accordion-body">

                                    <h4 class="t-header">معلومات المورد</h4><hr>

                                    <br>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                                        <div class="row gutters">
                                            <div class="col-xl-4 col-lglg-4 col-md-4 col-sm-4 col-12">
                                                <div class="form-group">
                                                    <label for="inputName">رقم الفاتورة</label>
                                                    <input type="numbers" class="form-control" id="inputName" placeholder="ادخل رقم الفاتورة" >
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-lglg-4 col-md-4 col-sm-4 col-12">
                                                <div class="form-group">
                                                    <label for="inputName">اسم المورد</label>
                                                    <input type="text" class="form-control" id="inputName"  disabled>
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-lglg-4 col-md-4 col-sm-4 col-12">
                                                <div class="form-group">
                                                    <label for="inputName">رقم الجوال</label>
                                                    <input type="text" class="form-control" id="inputName"  disabled>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row gutters justify-content-right">

                                            <div class="col-md-2">
                                                <button class="btn btn-primary btn-block "><i class="fa fa-plus"></i> @lang('site.search')</button>
                                            </div>

                                        </div>

                                    </div>

                                    <br>

                                    {{-- بعد الاضافة تجي هنا البيانات --}}
                                    <form action="#" method="post">

                                        {{ csrf_field() }}
                                        {{ method_field('post') }}

                                        @include('partials._errors')
                                        <div class="table-container">
                                            <div class="table-responsive">
                                                <table class="table custom-table m-0">
                                                    <thead>
                                                        <tr>
                                                            <th>رقم الكود</th>
                                                            <th>اسم القطعة</th>
                                                            <th>الكمية /  الوزن</th>
                                                            <th>سعر الشراء</th>
                                                            <th>اكشن</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="sale-list">
                                                        <tr>
                                                            <td>100056 </td>
                                                            <td>ساعة سولتير</td>
                                                            <td>10.2 g</td>
                                                            <td>1002 SR</td>
                                                            <td><span class="btn btn-block btn-danger"><i class="icon-remove_circle"></i></span></td>
                                                        </tr>
                                                        <tr>
                                                            <td>100056 </td>
                                                            <td>خاتم سولتير</td>
                                                            <td>10.2 g</td>
                                                            <td>1002 SR</td>
                                                            <td><span class="btn btn-block btn-danger"><i class="icon-remove_circle"></i></span></td>
                                                        </tr>
                                                        <tr>
                                                            <td>100056 </td>
                                                            <td>حلق سولتير</td>
                                                            <td>10.2 g</td>
                                                            <td>1002 SR</td>
                                                            <td><span class="btn btn-block btn-danger"><i class="icon-remove_circle"></i></span></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        <h4>@lang('site.total') : <span class="total-price">0</span></h4>

                                        <div class="row gutters justify-content-center">

                                            <div class="col-md-2">
                                                <button class="btn btn-primary btn-block disabled" id="add-order-form-btn"><i class="fa fa-plus"></i> @lang('site.return_back_sale')</button>
                                            </div>

                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Row end -->


        </div>

@endsection
