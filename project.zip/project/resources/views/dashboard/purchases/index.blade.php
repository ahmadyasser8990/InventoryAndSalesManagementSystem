@extends('layouts.dashboard.app')


@section('content')

        <!-- Page header start -->
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="{{asset('dashboard/purchases')}}">Purchase</a></li>
            </ol>
        </div>
        <!-- Page header end -->


        <!-- Content wrapper start -->
        <div class="content-wrapper">

            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                    <div class="accordion toggle-icons lg" id="toggleIcons">
                        <div class="accordion-container">
                            <div class="accordion-header" id="purchase_bill">
                                <a  href="" class="" data-toggle="collapse" data-target="#toggleIconsCollapseOne" aria-expanded="true" aria-controls="toggleIconsCollapseOne">
                                    Purchase
                                </a>
                            </div>
                            <div id="toggleIconsCollapseOne" class="collapse show" aria-labelledby="purchase_bill" data-parent="#toggleIcons">
                                <div class="accordion-body">
                                    <form action="{{asset('dashboard/purchases/invoice')}}" method="get">

                                        {{ csrf_field() }}
                                        {{ method_field('get') }}
                                        <div class="table-container">
                                            <div class="t-header"> Supplier Info</div>

                                            <br>

                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="row gutters">
                                                    <div class="col-xl-4 col-lglg-4 col-md-4 col-sm-4 col-12">
                                                        <div class="form-group">
                                                            <label for="inputName">Supplier Name</label>
                                                            <input type="text" class="form-control" id="inputName" placeholder="ادخل اسم المورد">
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lglg-4 col-md-4 col-sm-4 col-12">
                                                        <div class="form-group">
                                                            <label for="inputName"> Phone Number</label>
                                                            <input type="text" class="form-control" id="inputName" placeholder="ادخل رقم الجوال">
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="table-responsive">
                                                <table class="table custom-table m-0">
                                                    <thead>
                                                        <tr>
                                                            <th>Item Code</th>
                                                            <th>Item Name</th>
                                                            <th>Quantity Name</th>
                                                            <th> Purchase Price</th>
                                                            <th><span class="btn btn-block btn-success"><i class="icon-circle-with-plus"></i></span></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td><input type="text" class="form-control" name="code" placeholder="كوود"></td>
                                                            <td><input type="text" class="form-control" name="itemName" placeholder="اسم القطعة"></td>
                                                            <td><input type="number" class="form-control" name="stock" placeholder="الكمية"></td>
                                                            <td><input type="number" class="form-control" name="purchasePrice" placeholder="سعر الشراء"></td>
                                                            <td><span class="btn btn-block btn-danger"><i class="icon-remove_circle"></i></span></td>

                                                        </tr>
                                                    </tbody>
                                                </table>

                                            </div>

                                            <div class="row gutters">
                                                <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-6 col-12">
                                                    <div class="form-group">
                                                        <label >Notes</label>
                                                        <input type="text" class="form-control" name="note" placeholder=" Note">
                                                    </div>
                                                </div>
                                                <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-6 col-12">
                                                    <div class="form-group">
                                                        <label>  Totally <span class="total_price">00</span></label>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row gutters justify-content-center">

                                            <div class="col-md-2">
                                                <button type="submit" class="btn btn-primary btn-block" id="add-order-form-btn"><i class="fa fa-plus"></i> Purchase</button>
                                            </div>

                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Row end -->


        </div>

@endsection
