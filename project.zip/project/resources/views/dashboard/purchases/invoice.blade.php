@extends('layouts.dashboard.app')


@section('content')

        <!-- Page header start -->
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="{{asset('dashboard/sales')}}">Purchases</a></li>
                <li class="breadcrumb-item active"><a href="{{asset('dashboard/sales/invoice')}}">Invoice</a></li>
            </ol>
        </div>
        <!-- Page header end -->


        <!-- Content wrapper start -->
				<div class="content-wrapper">


					<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<div class="card">
								<div class="card-body p-0">
									<div class="invoice-container">

                                        <!-- Row start -->
											<div class="row gutters">
												<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
													<div class="custom-actions-btns mb-5">
														<a href="#" class="btn btn-primary">
															<i class="icon-export"></i> Export
														</a>
														<a href="#" class="btn btn-dark print-sale-btn">
															<i class="icon-printer"></i> Print
														</a>
                                                        <a href="{{route('dashboard.welcome')}}" class="btn btn-danger ">
															<i class="icon-back"></i> Back
														</a>
													</div>
												</div>
											</div>
											<!-- Row end -->
                                        <div id="invoice-area">
                                            <div class="invoice-header">

                                                <!-- Row start -->
                                                <div class="row gutters">
                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <a href="index.html" class="invoice-logo">
                                                            <img src="{{asset('dashboard_files/img/logo_4.png')}}" alt="Wafi Admin Dashboard" />
                                                        </a>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                        <address class="text-right">
                                                           Company Details<br />
                                                            سر الفضيات<br />
                                                            0580891057
                                                        </address>
                                                    </div>
                                                </div>
                                                <!-- Row end -->

                                                <!-- Row start -->
                                                <div class="row gutters">
                                                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-8 col-12">
                                                        <div class="invoice-details">
                                                            <address>
                                                                Supplier Name<br/>
                                                                Phone Number
                                                            </address>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3 col-sm-4 col-12">
                                                        <div class="invoice-details">
                                                            <div class="invoice-num">
                                                                <div>Invoice ID - #100 </div>
                                                                <div>15/5/2021</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Row end -->

                                            </div>

                                            <div class="invoice-body">

                                                <!-- Row start -->
                                                <div class="row gutters">
                                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                                        <h3 class="text-center">Purchase Invoice</h3><br>
                                                        <div class="table-responsive">
                                                            <table class="table table-bordered">
                                                                <thead>
                                                                    <tr>

                                                                        <th>Item Code</th>
                                                                        <th>Item Name</th>
                                                                        <th>Quantity</th>
                                                                        <th> Purchase Price </th>
                                                                        <th> Total </th>

                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    @for ($i=0; $i<3; $i++)
                                                                    <tr>

                                                                        <td>
                                                                            #50000981
                                                                        </td>
                                                                        <td>خاتم فضة ملكي</td>
                                                                        <td>9 جرام</td>
                                                                        <td>55.00 Riyal</td>
                                                                        <td>1500.00 Riyal</td>

                                                                    </tr>
                                                                    @endfor
                                                                    <tr>
                                                                        <td>&nbsp;</td>
                                                                        <td colspan="3">
                                                                            <p>
                                                                                Totally Items<br>
                                                                                15% Tax <br>
                                                                            </p>
                                                                            <h5 class="text-danger"><strong>Total Payment</strong></h5>
                                                                        </td>
                                                                        <td>
                                                                            <p>
                                                                                7000.00 Riyal<br>
                                                                                150.00 Riyal<br>
                                                                            </p>
                                                                            <h5 class="text-danger"><strong>7150.00 Riyal</strong></h5>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Row end -->
                                            </div>

                                            <div class="invoice-footer">
                                                Thanks for paying from [Company Name]
                                            </div>

                                        </div>

									</div>
								</div>
							</div>
						</div>

					</div>
					<!-- Row end -->


				</div>
				<!-- Content wrapper end -->

@endsection
