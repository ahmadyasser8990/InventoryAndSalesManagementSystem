@extends('layouts.dashboard.app')


@section('content')

        <!-- Page header start -->
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('dashboard.welcome')}}">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="{{asset('dashboard/sales')}}">Sale</a></li>
            </ol>
        </div>
        <!-- Page header end -->


        <!-- Content wrapper start -->
        <div class="content-wrapper">

            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                    <div class="accordion toggle-icons lg" id="toggleIcons">
                        <div class="accordion-container">
                            <div class="accordion-header" id="purchase_bill">
                                <a  href="" class="" data-toggle="collapse" data-target="#toggleIconsCollapseOne" aria-expanded="true" aria-controls="toggleIconsCollapseOne">
                                    Sale Invoice
                                </a>
                            </div>
                            <form action="{{route('dashboard.sales.store')}}" method="POST">

                                {{ csrf_field() }}
                                {{ method_field('post') }}

                                <div id="toggleIconsCollapseOne" class="collapse show" aria-labelledby="purchase_bill" data-parent="#toggleIcons">
                                    <div class="accordion-body">

                                        <div class="table-container">
                                            <div class="t-header">Customer Info</div>

                                            <br>

                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="row gutters">
                                                    <div class="col-xl-4 col-lglg-4 col-md-4 col-sm-4 col-12">
                                                        <div class="form-group">
                                                            <label > Customer Name</label>
                                                            <input type="text" name="customer_name" class="form-control"  placeholder="ادخل اسم الزبون">
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lglg-4 col-md-4 col-sm-4 col-12">
                                                        <div class="form-group">
                                                            <label >Phone Number</label>
                                                            <input type="number" name="customer_phone" class="form-control"  placeholder="ادخل رقم الجوال">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row gutters">
                                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                                                    <label > Payment Method</label>

                                                    <!-- Radios Payment_method -->
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="payment_method" name="payment_method" value="Cash" checked class="custom-control-input">
                                                        <label class="custom-control-label" for="payment_method"> Cash</label>
                                                    </div>

                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="payment_method" name="payment_method" value="Bank"  class="custom-control-input">
                                                        <label class="custom-control-label" for="payment_method">Transfer Bank</label>
                                                    </div>

                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="payment_method" name="payment_method" value="Credit Card"  class="custom-control-input">
                                                        <label class="custom-control-label" for="payment_method">Vise</label>
                                                    </div>

                                                </div>
                                            </div>

                                            <br>
                                            <div class="table-responsive">
                                                <table class="table custom-table m-0">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Item Code</th>
                                                            <th>Item Name</th>
                                                            <th> Quantity</th>
                                                            <th>Sale Price</th>
                                                            <th>Total</th>
                                                            <th><a class="btn btn-sm btn-success add_more"><i class="icon-plus"></i></a></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="addMoreProduct">
                                                        <tr>
                                                            <td>1</td>
                                                            <td>
                                                                <select name="product_id[]" id="product_id" class="form-control product_id">

                                                                    <option value="">Item Code</option>
                                                                    @foreach ($products as $product)
                                                                        <option data-name="{{$product->name}}" value="{{$product->id}}">{{$product->name}}</option>

                                                                    @endforeach
                                                                </select>
                                                            </td>
                                                            <td><input type="text" class="form-control input-sm name " name="name[]"  placeholder="Item Name " disabled></td>
                                                            <td><input type="number" class="form-control input-sm quantity" name="quantity[]"  min="1" value="1" placeholder="Quantity"></td>
                                                            <td><input type="number" class="form-control input-sm sale_price" step="0.01" name="sale_price[]" placeholder="Sale Price "></td>
                                                            <td> <p> <b><span class="amount" name="amount[]">0</span> Riyal </b> </p></td>
                                                            <td><a class="btn btn-sm btn-danger"><i class="icon-remove_circle"></i></a></td>

                                                        </tr>
                                                    </tbody>
                                                </table>


                                            </div>

                                            <div class="row gutters">
                                                <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-6 col-12">
                                                    <div class="form-group">
                                                        <label >Notes</label>
                                                        <input type="text" class="form-control" name="note" placeholder=" Note">
                                                    </div>
                                                </div>
                                                <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-6 col-12">
                                                    <div class="form-group">
                                                        <label>  Totally <span class="total_price">00</span></label>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row gutters justify-content-center">

                                            <div class="col-md-2">
                                                <button type="submit" class="btn btn-primary btn-block disabled" id="add-order-form-btn"><i class="fa fa-plus"></i> Sale</button>
                                            </div>

                                        </div>

                                        {{-- بعد الاضافة تجي هنا البيانات
                                        <form action="{{asset('dashboard/sales/invoice')}}" method="get">

                                            {{ csrf_field() }}
                                            {{ method_field('get') }}

                                            @include('partials._errors')
                                            <div class="table-container">
                                                <div class="table-responsive">
                                                    <table class="table custom-table m-0">
                                                        <thead>
                                                            <tr>
                                                                <th>رقم الكود</th>
                                                                <th>اسم الصنف</th>
                                                                <th>الكمية /  الوزن</th>
                                                                <th>السعر</th>
                                                                <th>اجمالي</th>
                                                                <th>اكشن</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="sale-list">

                                                            <tr>
                                                                <td>100054 </td>
                                                                <td>خاتم سولتير</td>
                                                                <td>10.2 g</td>
                                                                <td>1002 SR</td>
                                                                <td>1152</td>
                                                                <td><span class="btn btn-block btn-danger"><i class="icon-remove_circle"></i></span></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <br>




                                            </div>

                                            <h4>@lang('site.total') : <span class="total-price">0</span></h4>

                                            <div class="row gutters justify-content-center">

                                                <div class="col-md-2">
                                                    <button class="btn btn-primary btn-block" id="add-order-form-btn"><i class="fa fa-plus"></i> @lang('site.sale')</button>
                                                </div>

                                            </div>
                                        </form> --}}
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Row end -->


        </div>

@endsection


