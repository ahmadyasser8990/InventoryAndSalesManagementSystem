<!doctype html>
<html dir="{{ LaravelLocalization::getCurrentLocaleDirection() }}">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Meta -->
    <meta name="description" content="Responsive Bootstrap4 Dashboard Template">
    <meta name="author" content="ParkerThemes">
    <link rel="shortcut icon" href="{{asset('dashboard_files/img/fav.png')}}" />

    <!-- Title -->
    <title>Wafi Admin Template - Drag - Drop Cards Layout</title>


    <!--************ Common Css Files ************* -->

    <!-- Bootstrap css -->
    <link rel="stylesheet" href="{{asset('dashboard_files/css/bootstrap.min.css')}}">

    <!-- Icomoon Font Icons css -->
    <link rel="stylesheet" href="{{asset('dashboard_files/fonts/style.css')}}">

    <!-- Main css -->
    <link rel="stylesheet" href="{{asset('dashboard_files/css/main.css')}}">


    <!-- ************ Vendor Css Files *************\ -->
    <!-- DateRange css -->
    <link rel="stylesheet" href="{{asset('dashboard_files/vendor/daterange/daterange.css')}}" />

    <!-- Lobipanel css -->
    <link rel="stylesheet" href="{{asset('dashboard_files/vendor/lobipanel/css/lobipanel.css')}}" />


    <!-- Data Tables -->
    <link rel="stylesheet" href="{{asset('dashboard_files/vendor/datatables/dataTables.bs4.css')}}" />
    <link rel="stylesheet" href="{{asset('dashboard_files/vendor/datatables/dataTables.bs4-custom.css')}}" />

    <link href="{{asset('dashboard_files/vendor/datatables/buttons.bs.css')}}" rel="stylesheet" />

    {{--noty--}}
    <link rel="stylesheet" href="{{ asset('dashboard_files/plugins/noty/noty.css') }}">
    <script src="{{ asset('dashboard_files/plugins/noty/noty.min.js') }}"></script>

    @if (app()->getLocale() == 'ar')

    <link href="https://fonts.googleapis.com/css?family=Cairo:400,700" rel="stylesheet">

        <style>
            body, h1, h2, h3, h4, h5, h6, span, a {
                font-family: 'Cairo', sans-serif !important;
            }
        </style>
    @endif
</head>

<body>

    {{-- <!-- Loading starts -->
    <div id="loading-wrapper">
        <div class="spinner-border" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Loading ends --> --}}


    <!-- *************
			************ Header section start *************
		************* -->

        @include('layouts.dashboard._header')

    <!-- Screen overlay start -->
    <div class="screen-overlay"></div>
    <!-- Screen overlay end -->

    <!-- *************
			************ Header section end *************
		************* -->


    <div class="container-fluid">



        @include('layouts.dashboard._aside')


        <!-- ************* Main container start ************* -->
        <div class="main-container">


            @yield('content')

        </div>
        <!-- ************* Main container end ************* -->

            @include('partials._session')

        <!-- Footer start -->
        <footer class="main-footer">© Ahmed Yasser 2021</footer>
        <!-- Footer end -->


    </div>

    <!-- *************
			************ Required JavaScript Files *************
		************* -->
    <!-- Required jQuery first, then Bootstrap Bundle JS -->
    <script src="{{asset('dashboard_files/js/jquery.min.js')}}"></script>
    <script src="{{asset('dashboard_files/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('dashboard_files/js/moment.js')}}"></script>


    <!-- *************
			************ Vendor Js Files *************
		************* -->
    <!-- Slimscroll JS -->
    <script src="{{asset('dashboard_files/vendor/slimscroll/slimscroll.min.js')}}"></script>
    <script src="{{asset('dashboard_files/vendor/slimscroll/custom-scrollbar.js')}}"></script>

    <!-- Daterange -->
    <script src="{{asset('dashboard_files/vendor/daterange/daterange.js')}}"></script>
    <script src="{{asset('dashboard_files/vendor/daterange/custom-daterange.js')}}"></script>

    <!-- jQuery UI -->
    <script src="{{asset('dashboard_files/js/jquery-ui.min.js')}}"></script>

    <!-- Lobipanel -->
    <script src="{{asset('dashboard_files/vendor/lobipanel/js/lobipanel.js')}}"></script>
    <script src="{{asset('dashboard_files/vendor/lobipanel/js/lobipanel-custom.js')}}"></script>

    <!-- Main Js Required -->
    <script src="{{asset('dashboard_files/js/main.js')}}"></script>

    <!-- Data Tables -->
    <script src="{{asset('dashboard_files/vendor/datatables/dataTables.min.js')}}"></script>
    <script src="{{asset('dashboard_files/vendor/datatables/dataTables.bootstrap.min.js')}}"></script>

    <!-- Custom Data tables -->
    <script src="{{asset('dashboard_files/vendor/datatables/custom/custom-datatables.js')}}"></script>
    <script src="{{asset('dashboard_files/vendor/datatables/custom/fixedHeader.js')}}"></script>

    {{-- Custom js  --}}
    <script src="{{ asset('js/custom/report.js') }}"></script>

    {{-- Custom js  --}}
    <script src="{{ asset('js/custom/orders.js') }}"></script>

    {{--jquery number--}}
    <script src="{{ asset('dashboard_files/js/jquery.number.min.js') }}"></script>


    {{--ckeditor standard--}}
    <script src="{{ asset('dashboard_files/plugins/ckeditor/ckeditor.js') }}"></script>


    {{--print this--}}
    <script src="{{ asset('dashboard_files/js/printThis.js') }}"></script>

    <script>
        $(document).ready(function () {

            // image preview
            $(".image").change(function() {

                if (this.files && this.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('.image-preview').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(this.files[0]);
                }

            });


            //delete
            $('.delete').click(function (e) {

                var that = $(this)

                e.preventDefault();

                var n = new Noty({
                    text: "Are You Sure You Want to Delete This? ",
                    type: "success",
                    killer: true,
                    buttons: [
                        Noty.button("Yes", 'btn btn-primary mr-2', function () {
                            that.closest('form').submit();
                        }),

                        Noty.button("No", 'btn btn-danger mr-2', function () {
                            n.close();
                        })
                    ]
                });

                n.show();

            });//end of delete

            CKEDITOR.config.language =  "{{ app()->getLocale() }}";

        });//end of ready

    </script>
</body>

</html>
