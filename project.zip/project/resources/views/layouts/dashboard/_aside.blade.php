        <!-- Navigation start -->
        <nav class="navbar navbar-expand-lg custom-navbar">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#WafiAdminNavbar" aria-controls="WafiAdminNavbar" aria-expanded="false" aria-label="Toggle navigation">

                <span class="navbar-toggler-icon">
                    <i></i>
                    <i></i>
                    <i></i>
				</span>

			</button>

            <div class="collapse navbar-collapse" id="WafiAdminNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active-page" href="{{route('dashboard.welcome')}}" >
                            <i class="icon-devices_other nav-icon"></i> Dashboard
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- Navigation end -->
