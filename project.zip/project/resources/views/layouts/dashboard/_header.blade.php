  <!-- Header start -->
  <header class="header">
    <div class="logo-wrapper">
        <a href="{{route('dashboard.welcome')}}" class="logo">
            <img src="{{asset('dashboard_files/img/logo_3.png')}}"  />
        </a>
    </div>
    <div class="header-items">
        <!-- Custom search start -->
        {{-- <div class="custom-search">
            <input type="text" class="search-query" placeholder="Search here ...">
            <i class="icon-search1"></i>
        </div> --}}
        <!-- Custom search end -->

        <!-- Header actions start -->
        <ul class="header-actions">
            <li></li>
            <li></li>
            <li class="dropdown">
                <a href="#" id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
                    <span class="user-name">{{auth()->user()->first_name}} {{auth()->user()->last_name}}</span>
                    <span class="avatar">AY<span class="status busy"></span></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userSettings">
                    <div class="header-profile-actions">
                        <div class="header-user-profile">
                            <div class="header-user">
                                <img src="{{asset('dashboard_files/img/user.jpg')}}" alt="Admin Template" />
                            </div>
                            <h5>{{auth()->user()->first_name}} {{auth()->user()->last_name}}</h5>
                            <p>Programmer</p>
                        </div>
                        <a href="user-profile.html"><i class="icon-user1"></i>Profile</a>

                        <a href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <i class="icon-log-out1"></i>Logout
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>

                    </div>
                </div>
            </li>
            <li class="dropdown">
                <a href="#" id="notifications" data-toggle="dropdown" aria-haspopup="true">
                    <i class="icon-box"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right lrg" aria-labelledby="notifications">

                    <ul class="header-tasks">

                        @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                            <li>
                                <a rel="alternate" hreflang="{{ $localeCode }}" href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}">
                                    {{ $properties['native'] }}
                                </a>
                            </li>
                        @endforeach

                    </ul>
                </div>
            </li>
            <li> </li> <!-- keep it the <li></li> -->
        </ul>
        <!-- Header actions end -->
    </div>
</header>
<!-- Header end -->
