<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Meta -->
		<meta name="description" content="Responsive Bootstrap4 Dashboard Template">
		<meta name="author" content="ParkerThemes">
		<link rel="shortcut icon" href="{{asset('dashboard_files/img/fav.png')}}" />

		<!-- Title -->
		<title>@lang('site.login')</title>

		<!-- ************* Common Css Files *************-->
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="{{asset('dashboard_files/css/bootstrap.min.css')}}" />

		<!-- Master CSS -->
		<link rel="stylesheet" href="{{asset('dashboard_files/css/main.css')}}" />

        {{-- نوع الخط --}}
        <link href="https://fonts.googleapis.com/css?family=Cairo:400,700" rel="stylesheet">

        <style>
            body, h1, h2, h3, h4, h5, h6, span, a {
                font-family: 'Cairo', sans-serif !important;
            }
        </style>

	</head>

	<body class="authentication">

		<!-- Container start -->
		<div class="container">

			@yield('content')

		</div>
		<!-- Container end -->

	</body>
</html>
