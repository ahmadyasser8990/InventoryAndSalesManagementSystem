<?php

return [

    // القوائم
    'dashboard' => 'الرئيسيه',
    'suppliers' => 'الموردين',
    'store' => 'المخزون',
    'sales' => 'المبيعات',
    'purchases' => 'المشتريات',


    'logout' => 'تسجيل الخروج',
    'sale_graph_daily' => 'ملخص المبيعات باليوم',
    'sale_graph_monthly' => 'ملخص المبيعات بالاشهر',
    'navigation' => 'القوائم',
    'profile' => 'البروفايل',
    'total_purchase' => 'اجمالي المشتريات',
    'total_sales' => 'اجمالي المبيعات',
    'total_store' => 'اجمالي المخزون',
    'profits' => 'اجمالي المربح',
    'purchase_bill' => 'فاتورة شراء',
    'sale_bill' => 'فاتورة بيع ',
    'bills' => 'قائمة الفواتير',
    'return_sale' => 'مرتجع مبيعات',
    'purchase_return_back' => 'مرتجع مشتريات',
    'reports' => 'التقارير',
    'invoice' => 'فاتورة',


    // reports

    'show_report' => 'عرض الفاتورة',



    // Purchases
    'bill_no' => 'رقم الفاتورة',
    'phone_no' => ' رقم الجوال',
    'client_name' => 'اسم العميل',
    'item_name' => 'اسم الصنف',
    'item_code' => 'رقم الصنف',
    'item_wight' => 'الوزن',
    'item_count' => 'الكمية',
    'item_sale' => 'السعر',
    'notes' => 'ملاحظة',
    'total' => 'الاجمالي',
    'sale' => 'بيع',
    'purchase' => 'شراء',


    //return_purchase
    'return_purchase' => 'مرتجع مشتريات',



    // return_sale

    'return_back_sale' => 'استرجاع',

    'add' => 'اضف',
    'create' => 'اضافه',
    'read' => 'عرض',
    'edit' => 'تعديل',
    'update' => 'تعديل',
    'delete' => 'حذف',
    'close' => 'الغاء',
    'search' => 'بحث',
    'searchCategory' => ' بحث عن قسم ',
    'show' => 'عرض',
    'loading' => 'جاري التحميل',
    'print' => 'طبع',

    'confirm_delete' => 'تاكيد الحذف',
    'yes' => 'نعم',
    'no' => 'لا',

    'login' => 'تسجيل الدخول',
    'remember_me' => 'تذكرني',
    'password' => 'كلمه المرور',
    'password_confirmation' => 'تاكيد كلمه المرور',

    'added_successfully' => 'تم اضافه البيانات بنجاح',
    'updated_successfully' => 'تم تعديل البيانات بنجاح',
    'deleted_successfully' => 'تم حذف البيانات بنجاح',

    'no_data_found' => 'للاسف لا يوجد اي سجلات',
    'no_records' => 'للاسف لا يوجد اي سجلات',

    'clients' => 'العملاء',
    'client_name' => 'اسم العميل',
    'phone' => 'التلفون',
    'address' => 'العنوان',
    'previous_orders' => 'الطلبات السابقه',
    'no_records_history' => 'للاسف لا يوجد طلبات سابقة لهذا العميل',
    'orders' => 'الطلبات',
    'add_order' => 'اضف طلب',
    'edit_order' => 'تعديل طلب',

    // users
    'users' => 'المشرفين',
    'first_name' => 'الاسم الاول',
    'last_name' => 'الاسم الاخير',
    'email' => 'البريد الاكتروني',
    'image' => 'صوره',
    'action' => 'اكشن',
    'create_user' => 'مشرف جديد',
    'edit_user' => 'تعديل مشرف ',
    'permissions_users' => 'صلاحيات المشرفين',
    'permissions_sales' => 'صلاحيات المبيعات',
    'permissions_purchases' => 'صلاحيات المشتريات',
    'permissions_products' => 'صلاحيات المخزون',
    'permissions_categories' => 'صلاحيات الاقسام',
    'permissions_suppliers' => 'صلاحيات الموردين',
    'permissions_reports' => 'صلاحيات التقارير',
    'create_supplier' => 'اظافة مورد جديد',

    'permissions' => 'الصلاحيات',

    'categories' => 'الاقسام',
    'new_category' => 'قسم جديد',
    'edit_category' => 'قسم جديد',
    'all_categories' => 'كل الاقسام',
    'name' => 'الاسم',
    'description' => 'الوصف',
    'products_count' => 'عدد الامنتجات',
    'related_products' => 'المنتجات المرتبطه',
    'category' => 'القسم',
    'show_products' => 'عرض المنتجات',
    'created_at' => 'تم اضافته',
    'created_at' => 'تم اضافته',
    'export' => 'تحميل ',


    'products' => 'المنتجات',
    'product' => 'الصنف',
    'code' => 'رقم الصنف',
    'quantity' => 'الكميه',
    'create_product' => 'مخزون جديد',
    // 'total' => 'المجموع',
    'purchase_price' => 'سعر الشراء',
    'price' => 'السعر',
    'sale_price' => 'سعر البيع',
    'stock' => 'المخزن',
    'profit_percent' => 'المكسب',

    'ar' => [
        'name' => 'الاسم بالغه العربيه',
        'description' => 'الوصف بالغه العربيه',
    ],

    'en' => [
        'name' => 'الاسم بالغه الانجليزيه',
        'description' => 'الوصف بالغه الانجليزيه',
    ],

];
