<?php $__env->startSection('content'); ?>

    <!-- Page header start -->
    <div class="page-header">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="<?php echo e(route('dashboard.welcome')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.products.index')); ?>">Store</a></li>
            <li class="breadcrumb-item active">Edit</li>
        </ol>
    </div>
    <!-- Page header end -->

<!-- Content wrapper start -->
<div class="content-wrapper">
    <!-- Row start -->
    <div class="row gutters">

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

            <div class="card h-100">

                <div class="card-header">
                    <div class="card-title">Edit</div>
                </div>

                <div class="card-body">

                    <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <form action="<?php echo e(route('dashboard.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">

                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('put')); ?>


                        <div class="row gutters">

                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">

                                <div class="form-group">

                                    <label>Category</label>

                                    <select name="category_id" class="form-control">

                                        <option value="">All Category</option>

                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label >Item Code</label>
                                    <input type="text" class="form-control" name="code" value="<?php echo e($product->code); ?>" placeholder="ادخل رقم الصنف الجديد" >
                                </div>
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="name" value="<?php echo e($product->name); ?>" placeholder="ادخل اسم الصنف" >
                                </div>
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea name="description" class="form-control ckeditor"><?php echo e($product->description); ?></textarea>
                                </div>
                            </div>

                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">

                                <div class="form-group">
                                    <label >Stock</label>
                                    <input type="number" class="form-control" name="stock" value="<?php echo e($product->stock); ?>" placeholder="ادخل الكمية / الوزن" >
                                </div>

                                <div class="form-group">
                                    <label>Purchase Price</label>
                                    <input type="number" class="form-control" name="purchase_price" step="0.01" value="<?php echo e($product->purchase_price); ?>" placeholder="ادخل سعر الشراء" >
                                </div>

                                <div class="form-group">

                                    <label>Image</label>
                                    <input type="file" name="image" class="form-control image">

                                </div>
                                <div class="form-group">

                                    <img src="<?php echo e($product->image_path); ?>" style="width: 100px;" class=" image-preview" >

                                </div>

                            </div>

                        </div>
                            <!-- Row start -->
                        <div class="row gutters">

                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="">

                                    <a href="<?php echo e(route('dashboard.products.index')); ?>"  class="btn btn-dark">Cancel</a>

                                    <button type="submit" class="btn btn-success">Edit</button>
                                </div>
                            </div>


                        </div>
                        <!-- Row end -->

                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- Row end -->

</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>