<?php $__env->startSection('content'); ?>



            <!-- Page header start -->
            <div class="page-header">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div>
            <!-- Page header end -->


            <!-- Content wrapper start -->
            <div class="content-wrapper">

                <!-- Row start -->
                <div class="row gutters">
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">

                        
                        <?php if(auth()->user()->hasPermission('read_purchases')): ?>

                            <div class="card lobipanel-sortable">

                                <div class="card-header">
                                    <div class="card-title"><a href="<?php echo e(asset('dashboard/purchases')); ?>">Purchase</a></div>
                                </div>
                                <div class="card-body">
                                    Total Purchase Invoice: 10021
                                </div>

                            </div>

                        <?php endif; ?>

                        
                        <?php if(auth()->user()->hasPermission('read_sales')): ?>

                            <div class="card lobipanel-sortable">
                                <div class="card-header">
                                    <div class="card-title"><a href="<?php echo e(route('dashboard.sales.index')); ?>">Sale</a></div>
                                </div>
                                <div class="card-body">
                                    Total Sale Invoice: 10024
                                </div>
                            </div>

                            <div class="card lobipanel-sortable">
                                <div class="card-header">
                                    <div class="card-title"><a href="<?php echo e(asset('dashboard/return_sale')); ?>">Return Sale</a></div>
                                </div>
                                <div class="card-body">
                                    Total returned sale Invoice: 1542
                                </div>
                            </div>
                        <?php endif; ?>


                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">

                        
                        <?php if(auth()->user()->hasPermission('read_purchases')): ?>

                            <div class="card lobipanel-sortable">
                                <div class="card-header">
                                    <div class="card-title"><a href="<?php echo e(asset('dashboard/return_purchase')); ?>">Return Purchase</a></div>
                                </div>
                                <div class="card-body">
                                    Total Returned Purchase Invoice: 10021

                                </div>
                            </div>

                        <?php endif; ?>

                        
                        <?php if(auth()->user()->hasPermission('read_users')): ?>

                            <div class="card lobipanel-sortable">
                                <div class="card-header">
                                    <div class="card-title"><a href="<?php echo e(route('dashboard.users.index')); ?>">Users</a></div>
                                </div>
                                <div class="card-body">

                                    All Users are : <?php echo e($users_count); ?>


                                </div>
                            </div>

                        <?php endif; ?>

                        
                        <?php if(auth()->user()->hasPermission('read_reports')): ?>

                            <div class="card lobipanel-sortable">
                                <div class="card-header">
                                    <div class="card-title"><a href="<?php echo e(asset('dashboard/reports')); ?>">Reports</a></div>
                                </div>
                                <div class="card-body">
                                    Reports (Sales - Purchase)
                                </div>
                            </div>

                        <?php endif; ?>

                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                        
                        <?php if(auth()->user()->hasPermission('read_products') || auth()->user()->hasPermission('read_categories') ): ?>

                            <div class="card lobipanel-sortable">
                                <div class="card-header">
                                    <div class="card-title"><a href="<?php echo e(route('dashboard.products.index')); ?>">Store</a></div>
                                </div>
                                <div class="card-body">

                                    <ol class="">
                                        <li class="">Total Items <?php echo e($product_count); ?></li>
                                        <li class="">Total Categories <?php echo e($category_count); ?></li>
                                    </ol>

                                </div>
                            </div>

                        <?php endif; ?>

                        
                        <?php if(auth()->user()->hasPermission('read_suppliers')): ?>

                            <div class="card lobipanel-sortable">
                                <div class="card-header">
                                    <div class="card-title"><a href="<?php echo e(route('dashboard.suppliers.index')); ?>">Suppliers</a></div>
                                </div>
                                <div class="card-body">
                                    All Suppliers : <?php echo e($supplier_count); ?>

                                </div>
                            </div>

                        <?php endif; ?>
                    </div>
                </div>
                <!-- Row end -->

            </div>
            <!-- Content wrapper end -->





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>