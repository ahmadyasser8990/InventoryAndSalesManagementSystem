<?php $__env->startSection('content'); ?>

        <!-- Page header start -->
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(asset('dashboard/index')); ?>"><?php echo app('translator')->getFromJson('site.dashboard'); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(asset('dashboard/sales')); ?>"><?php echo app('translator')->getFromJson('site.sale_bill'); ?></a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(asset('dashboard/sales/invoice')); ?>"><?php echo app('translator')->getFromJson('site.invoice'); ?></a></li>
            </ol>
        </div>
        <!-- Page header end -->


        <!-- Content wrapper start -->
				<div class="content-wrapper">


					<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<div class="card">
								<div class="card-body p-0">
									<div class="invoice-container">

                                        <!-- Row start -->
											<div class="row gutters">
												<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
													<div class="custom-actions-btns mb-5">
														<a href="#" class="btn btn-primary">
															<i class="icon-export"></i> حفظ
														</a>
														<a href="#" class="btn btn-dark print-sale-btn">
															<i class="icon-printer"></i> طباعة
														</a>
                                                        <a href="<?php echo e(asset('dashboard/index')); ?>" class="btn btn-danger ">
															<i class="icon-back"></i> رجوع
														</a>
													</div>
												</div>
											</div>
											<!-- Row end -->
                                        <div id="invoice-area">
                                            <div class="invoice-header">

                                                <!-- Row start -->
                                                <div class="row gutters">
                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <a href="index.html" class="invoice-logo">
                                                            <img src="<?php echo e(asset('dashboard_files/img/logo_4.png')); ?>" alt="Wafi Admin Dashboard" />
                                                        </a>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                        <address class="text-right">
                                                            اسواق طيبة, محل رقم 14<br />
                                                            سر الفضيات<br />
                                                            0580891057
                                                        </address>
                                                    </div>
                                                </div>
                                                <!-- Row end -->

                                                <!-- Row start -->
                                                <div class="row gutters">
                                                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-8 col-12">
                                                        <div class="invoice-details">
                                                            <address>
                                                                اسم العميل<br />
                                                                رقم جواله
                                                            </address>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3 col-sm-4 col-12">
                                                        <div class="invoice-details">
                                                            <div class="invoice-num">
                                                                <div>رقم الفاتورة - #100 </div>
                                                                <div>15/5/2021</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Row end -->

                                            </div>

                                            <div class="invoice-body">

                                                <!-- Row start -->
                                                <div class="row gutters">
                                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                                        <h3 class="text-center">فاتورة بيع</h3><br>
                                                        <div class="table-responsive">
                                                            <table class="table table-bordered">
                                                                <thead>
                                                                    <tr>

                                                                        <th>رقم الكود</th>
                                                                        <th>اسم الصنف</th>
                                                                        <th>الكمية/الوزن</th>
                                                                        <th> السعر </th>
                                                                        <th> اجمالي </th>

                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php for($i=0; $i<3; $i++): ?>
                                                                    <tr>

                                                                        <td>
                                                                            #50000981
                                                                        </td>
                                                                        <td>خاتم فضة ملكي</td>
                                                                        <td>9 جرام</td>
                                                                        <td>55.00 ريال</td>
                                                                        <td>1500.00 ريال</td>

                                                                    </tr>
                                                                    <?php endfor; ?>
                                                                    <tr>
                                                                        <td>&nbsp;</td>
                                                                        <td colspan="3">
                                                                            <p>
                                                                                اجمالي الاصناف<br>
                                                                                15% القيمة المضافة<br>
                                                                            </p>
                                                                            <h5 class="text-danger"><strong>الاجمالي</strong></h5>
                                                                        </td>
                                                                        <td>
                                                                            <p>
                                                                                7000.00 ريال<br>
                                                                                150.00 ريال<br>
                                                                            </p>
                                                                            <h5 class="text-danger"><strong>7150.00 ريال</strong></h5>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Row end -->
                                            </div>

                                            <div class="invoice-footer">
                                                شكرا لشراك من سر الفضيات
                                            </div>

                                        </div>

									</div>
								</div>
							</div>
						</div>

					</div>
					<!-- Row end -->


				</div>
				<!-- Content wrapper end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>